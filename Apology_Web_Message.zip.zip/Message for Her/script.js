document.getElementById("playBtn").addEventListener("click", function ()
{
    const audio =
    document.getElementById("bgMusic");
    audio.play();
    alert("Thank you for listening to my heart 💗 I LOVE YOU SO FREAKING MUCH MY SAKUU 💗")
});

